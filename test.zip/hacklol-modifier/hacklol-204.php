<?php
	http_response_code(204);
?>