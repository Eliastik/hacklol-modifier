<?php
	$ip_ban_page_loader = array(
        '', ''
	);
?>
